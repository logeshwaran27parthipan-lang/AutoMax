"use client";

import React, { useEffect, useState } from "react";
import axios from "axios";
import { useParams, useRouter } from "next/navigation";

type Workflow = {
  id: string;
  name: string;
  description?: string;
  triggers: any[];
  steps: any[];
  createdAt: string;
};

export default function WorkflowDetailPage() {
  const params = useParams();
  const router = useRouter();
  const id = params?.id as string | undefined;

  const [workflow, setWorkflow] = useState<Workflow | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!id) return;
    fetchWorkflow();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  async function fetchWorkflow() {
    setLoading(true);
    setError(null);
    try {
      const res = await axios.get(`/api/workflows/${id}`);
      setWorkflow(res.data as Workflow);
    } catch (err: any) {
      console.error(err);
      setError(err?.response?.data?.error || "Failed to load workflow");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <button
              onClick={() => router.push("/dashboard/workflows")}
              className="px-3 py-2 bg-white rounded shadow hover:bg-gray-50"
            >
              ← Back
            </button>
            <h1 className="text-2xl font-semibold">Workflow details</h1>
          </div>
          <div>
            <button className="px-4 py-2 bg-white rounded shadow hover:bg-gray-50 mr-3">
              Edit
            </button>
          </div>
        </div>

        <div className="bg-white rounded shadow p-6 mb-6">
          {loading ? (
            <div className="flex items-center gap-3">
              <div className="w-6 h-6 border-4 border-blue-500 border-t-transparent rounded-full animate-spin" />
              <span className="text-gray-600">Loading workflow...</span>
            </div>
          ) : error ? (
            <div className="text-red-600">Error: {error}</div>
          ) : workflow ? (
            <div>
              <h2 className="text-xl font-bold mb-1">{workflow.name}</h2>
              <p className="text-sm text-gray-500 mb-4">
                {workflow.description || "No description"}
              </p>
              <div className="text-xs text-gray-400">
                Created {new Date(workflow.createdAt).toLocaleString()}
              </div>
            </div>
          ) : (
            <div className="text-gray-500">No workflow found.</div>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white rounded shadow p-6">
            <h3 className="font-semibold mb-3">Steps</h3>
            {loading ? null : workflow &&
              workflow.steps &&
              workflow.steps.length > 0 ? (
              <ul className="space-y-2">
                {workflow.steps.map((s, idx) => (
                  <li key={idx} className="p-3 border rounded bg-gray-50">
                    Step {idx + 1}
                  </li>
                ))}
              </ul>
            ) : (
              <div className="text-gray-500">No steps yet</div>
            )}
          </div>

          <div className="bg-white rounded shadow p-6">
            <h3 className="font-semibold mb-3">Triggers</h3>
            {loading ? null : workflow &&
              workflow.triggers &&
              workflow.triggers.length > 0 ? (
              <ul className="space-y-2">
                {workflow.triggers.map((t, idx) => (
                  <li key={idx} className="p-3 border rounded bg-gray-50">
                    Trigger {idx + 1}
                  </li>
                ))}
              </ul>
            ) : (
              <div className="text-gray-500">No triggers yet</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
