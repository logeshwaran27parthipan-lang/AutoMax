/**
 * Lightweight WhatsApp integration helper.
 * This module is intentionally minimal: no workflow/business logic —
 * only a small wrapper that sends a message to a configured WhatsApp HTTP
 * API (WAHA-style) endpoint.
 *
 * Usage:
 *   import { sendWhatsAppMessage } from '@/lib/validations/workflow';
 *   await sendWhatsAppMessage('+15551234567', 'Hello world');
 */

export async function sendWhatsAppMessage(
  to: string,
  message: string,
): Promise<{ success: boolean; result?: any; error?: string }> {
  if (!to || typeof to !== "string") {
    throw new Error('sendWhatsAppMessage: "to" phone number is required');
  }
  if (!message || typeof message !== "string") {
    throw new Error('sendWhatsAppMessage: "message" text is required');
  }

  const baseUrl = process.env.WAHA_API_URL;
  const apiKey = process.env.WAHA_API_KEY;

  if (!baseUrl) {
    throw new Error(
      "sendWhatsAppMessage: missing WAHA_API_URL environment variable",
    );
  }

  // Normalize URL and POST to /send by default
  const url = `${baseUrl.replace(/\/$/, "")}/send`;

  try {
    const res = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...(apiKey ? { Authorization: `Bearer ${apiKey}` } : {}),
      },
      body: JSON.stringify({ to, message }),
    });

    // Try to parse JSON response (if any)
    let data: any = null;
    try {
      data = await res.json();
    } catch (e) {
      // ignore JSON parse errors
    }

    if (!res.ok) {
      return {
        success: false,
        error: data?.error || `HTTP ${res.status}`,
        result: data,
      };
    }

    return { success: true, result: data };
  } catch (err: any) {
    return { success: false, error: String(err) };
  }
}
