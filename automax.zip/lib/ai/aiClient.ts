import { interpolate } from "@/lib/utils/interpolate";

export async function runAI(prompt: string): Promise<any> {
  try {
    const apiKey = process.env.GROQ_API_KEY;
    if (!apiKey) throw new Error("Missing GROQ_API_KEY");

    const res = await fetch("https://api.groq.com/openai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "llama-3.3-70b-versatile",
        messages: [
          {
            role: "system",
            content:
              'You are an automation engine. Return ONLY valid JSON in this exact format: { "action": "action_name", "params": {} }. Available actions: send_email, send_whatsapp, ai_process. No explanation, no markdown, just JSON.',
          },
          {
            role: "user",
            content: prompt,
          },
        ],
        temperature: 0,
      }),
    });

    if (!res.ok) {
      const err = await res.text();
      throw new Error(`Groq error: ${res.status} ${err}`);
    }

    const data = await res.json();
    const content = data.choices?.[0]?.message?.content || "{}";

    // Strip markdown code blocks if model wraps in ```json
    const cleaned = content.replace(/```json|```/g, "").trim();

    return JSON.parse(cleaned);
  } catch (err) {
    console.error("[AI ERROR]:", err);
    return { error: "PARSE_FAILED" };
  }
}
