import { prisma } from "@/lib/prisma";
import { actions } from "@/lib/actions";
import { runAI } from "@/lib/ai/aiClient";
import { interpolate } from "@/lib/utils/interpolate";
import { getRecentMessages, saveMessage } from "@/lib/memory/memoryService";

export async function processEvent(eventName: string, payload: any) {
  console.log("[PROCESS EVENT]:", eventName);

  const workflows = await prisma.workflow.findMany();

  const matchedWorkflows = workflows.filter((wf) => {
    const triggers = wf.triggers;

    if (Array.isArray(triggers)) {
      return triggers.some((t: any) => (t?.type || t) === eventName);
    }

    if (typeof triggers === "string") {
      return triggers === eventName;
    }

    return false;
  });

  console.log("[MATCHED WORKFLOWS]:", matchedWorkflows.length);

  for (const workflow of matchedWorkflows) {
    console.log("[RUNNING WORKFLOW]:", workflow.id);

    let steps: any[] = [];

    try {
      steps = Array.isArray(workflow.steps)
        ? workflow.steps
        : JSON.parse(workflow.steps as any);
    } catch {
      steps = [];
    }

    for (let i = 0; i < steps.length; i++) {
      const step = steps[i];

      const userId = payload.userId || workflow.userId;

      // =============================
      // 💾 SAVE USER MESSAGE (MEMORY)
      // =============================
      if (payload.message) {
        await saveMessage(userId, payload.message, "user");
      }

      // =============================
      // 🤖 AI DECISION STEP (MULTI)
      // =============================
      if (step.type === "ai_decision") {
        console.log("[AI STEP]");

        try {
          const history = await getRecentMessages(userId);

          const historyText = history
            .map((m: any) => `${m.role}: ${m.message}`)
            .join("\n");

          const prompt = `Conversation history:
${historyText}

New message:
${interpolate(step.prompt, payload)}`;

          let aiResponse = await runAI(prompt);

          console.log("[RAW AI RESPONSE]:", aiResponse);

          if (typeof aiResponse === "string") {
            try {
              aiResponse = JSON.parse(aiResponse);
            } catch {
              console.log("❌ Invalid JSON from AI");
              continue;
            }
          }

          if (!aiResponse.steps || !Array.isArray(aiResponse.steps)) {
            console.log("❌ No steps returned by AI");
            continue;
          }

          for (const aiStep of aiResponse.steps) {
            const action = actions[aiStep.action as keyof typeof actions];

            if (!action) {
              console.log("❌ Unknown AI action:", aiStep.action);
              continue;
            }

            console.log("🤖 AI step:", aiStep.action);
            console.log("📦 Params:", aiStep.params);

            await action({
              ...aiStep.params,
              ...payload,
            });
          }

          // 💾 SAVE AI RESPONSE
          await saveMessage(userId, JSON.stringify(aiResponse), "ai");

        } catch (err) {
          console.log("AI step error:", err);
        }

        continue;
      }

      // =============================
      // 🧠 CONDITION STEP (RESTORED)
      // =============================
      if (step.type === "condition") {
        const actual = payload[step.field];

        let conditionPassed = false;

        if (step.operator === "includes") {
          conditionPassed =
            typeof actual === "string" && actual.includes(step.value);
        } else if (step.operator === "equals") {
          conditionPassed = actual === step.value;
        } else if (step.operator === "not_equals") {
          conditionPassed = actual !== step.value;
        }

        console.log("[CONDITION]:", conditionPassed);

        if (!conditionPassed) {
          console.log("❌ Condition failed → stopping workflow");
          break;
        }

        console.log("✅ Condition passed → continuing");
        continue;
      }

      // =============================
      // ⚙️ NORMAL ACTION STEP
      // =============================
      const action = actions[step.type as keyof typeof actions];

      if (!action) {
        console.log("No action:", step.type);
        continue;
      }

      try {
        await action({
          ...step,
          ...payload,
        });
      } catch (err) {
        console.log("Step error:", err);
      }
    }
  }
}