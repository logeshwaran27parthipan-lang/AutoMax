import { NextResponse } from "next/server";
import { emitEvent } from "@/lib/events/eventBus";

export async function GET() {
  await emitEvent("test_event", {
    message: "send email and whatsapp hello bro",
  });

  return NextResponse.json({ ok: true });
}